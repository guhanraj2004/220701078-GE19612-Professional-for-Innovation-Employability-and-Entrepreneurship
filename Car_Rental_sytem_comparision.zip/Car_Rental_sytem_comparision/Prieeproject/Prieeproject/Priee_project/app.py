from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
from flask_mysqldb import MySQL
import os
from dotenv import load_dotenv
import logging
import json
from datetime import datetime
import requests

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key-here')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cars.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'mysql123'
app.config['MYSQL_DB'] = 'car_rental_db'

# Email configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('EMAIL_USER')
app.config['MAIL_PASSWORD'] = os.getenv('EMAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('EMAIL_USER')
app.config['MAIL_MAX_EMAILS'] = None
app.config['MAIL_ASCII_ATTACHMENTS'] = False
app.config['MAIL_DEBUG'] = True

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
mail = Mail(app)
mysql = MySQL(app)

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20), nullable=False)

class Car(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    engine = db.Column(db.String(100))
    power = db.Column(db.String(50))
    transmission = db.Column(db.String(50))
    fuel_economy = db.Column(db.String(50))
    acceleration = db.Column(db.String(50))
    safety_rating = db.Column(db.Float)
    interior_space = db.Column(db.String(50))
    tech_features = db.Column(db.Text)
    pros = db.Column(db.Text)
    cons = db.Column(db.Text)
    reviews = db.relationship('Review', backref='car', lazy=True)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    car_id = db.Column(db.Integer, db.ForeignKey('car.id'), nullable=False)
    rating = db.Column(db.Float, nullable=False)
    comment = db.Column(db.Text)
    author = db.Column(db.String(100))
    date = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Demo rental websites data (in production, this would be scraped from actual websites)
RENTAL_SITES = {
    'speedyrent': {
        'name': 'SpeedyRent',
        'website': 'https://www.speedyrent.com',
        'cars': {
            'economy': {'base_rate': 50, 'per_mile': 0.15},
            'standard': {'base_rate': 70, 'per_mile': 0.20},
            'luxury': {'base_rate': 120, 'per_mile': 0.30},
            'suv': {'base_rate': 90, 'per_mile': 0.25}
        }
    },
    'easycar': {
        'name': 'EasyCar',
        'website': 'https://www.easycar.com',
        'cars': {
            'economy': {'base_rate': 45, 'per_mile': 0.12},
            'standard': {'base_rate': 65, 'per_mile': 0.18},
            'luxury': {'base_rate': 110, 'per_mile': 0.28},
            'suv': {'base_rate': 85, 'per_mile': 0.22}
        }
    }
}

# Fallback data for when demo websites are not available
FALLBACK_DATA = {
    'easycar': {
        'economy': {'model': 'Toyota Corolla', 'base_rate': 45.00, 'per_mile': 0.12},
        'standard': {'model': 'Honda Accord', 'base_rate': 65.00, 'per_mile': 0.18},
        'luxury': {'model': 'BMW 3 Series', 'base_rate': 110.00, 'per_mile': 0.28},
        'suv': {'model': 'Toyota RAV4', 'base_rate': 85.00, 'per_mile': 0.22}
    },
    'speedyrent': {
        'economy': {'model': 'Nissan Versa', 'base_rate': 50.00, 'per_mile': 0.15},
        'standard': {'model': 'Hyundai Elantra', 'base_rate': 70.00, 'per_mile': 0.20},
        'luxury': {'model': 'Mercedes C-Class', 'base_rate': 120.00, 'per_mile': 0.30},
        'suv': {'model': 'Ford Explorer', 'base_rate': 90.00, 'per_mile': 0.25}
    }
}

def calculate_rental_price(car_type, distance, site):
    cur = mysql.connection.cursor()
    table_name = 'easycar_inventory' if site == 'easycar' else 'speedyrent_inventory'
    
    cur.execute(f'''
        SELECT base_rate, per_mile_rate 
        FROM {table_name} 
        WHERE car_type = %s AND available = TRUE
        ORDER BY base_rate ASC 
        LIMIT 1
    ''', (car_type,))
    
    result = cur.fetchone()
    cur.close()
    
    if not result:
        return None
        
    base_rate, per_mile_rate = result
    # Convert Decimal to float before calculation
    base_rate = float(base_rate)
    per_mile_rate = float(per_mile_rate)
    return base_rate + (per_mile_rate * float(distance))

# Routes
@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('search'))
    return render_template('index.html')

@app.route('/compare')
def compare():
    cars = Car.query.all()
    return render_template('compare.html', cars=cars)

@app.route('/reviews')
def reviews():
    reviews = Review.query.order_by(Review.date.desc()).all()
    return render_template('reviews.html', reviews=reviews)

@app.route('/recommendations')
def recommendations():
    return render_template('recommendations.html')

@app.route('/api/cars')
def get_cars():
    cars = Car.query.all()
    return jsonify([{
        'id': car.id,
        'name': car.name,
        'price': car.price,
        'engine': car.engine,
        'power': car.power,
        'transmission': car.transmission,
        'fuel_economy': car.fuel_economy,
        'acceleration': car.acceleration,
        'safety_rating': car.safety_rating,
        'interior_space': car.interior_space,
        'tech_features': car.tech_features,
        'pros': car.pros.split(',') if car.pros else [],
        'cons': car.cons.split(',') if car.cons else []
    } for car in cars])

@app.route('/api/recommendations', methods=['POST'])
def get_recommendations():
    data = request.get_json()
    budget = float(data.get('budget', 35000))
    use = data.get('use', 'daily')
    features = data.get('features', [])

    # Simple recommendation logic based on budget and use case
    cars = Car.query.filter(Car.price <= budget).all()
    
    # Sort cars based on use case and features
    recommended_cars = []
    for car in cars:
        score = 0
        if use == 'daily' and 'fuel-economy' in features:
            score += 2
        if 'safety' in features and car.safety_rating >= 4.5:
            score += 2
        if 'performance' in features and float(car.acceleration.split()[0]) < 7:
            score += 2
        if 'tech' in features and len(car.tech_features.split(',')) > 5:
            score += 2

        if score > 0:
            recommended_cars.append({
                'id': car.id,
                'name': car.name,
                'price': car.price,
                'score': score
            })

    # Sort by score and return top 3
    recommended_cars.sort(key=lambda x: x['score'], reverse=True)
    return jsonify(recommended_cars[:3])

@app.route('/api/reviews', methods=['POST'])
def add_review():
    data = request.get_json()
    review = Review(
        car_id=data['car_id'],
        rating=float(data['rating']),
        comment=data['comment'],
        author=data['author']
    )
    db.session.add(review)
    db.session.commit()
    return jsonify({'message': 'Review added successfully'})

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        phone = request.form['phone']
        
        cur = mysql.connection.cursor()
        
        # Check if username exists
        cur.execute('SELECT * FROM users WHERE username = %s', (username,))
        if cur.fetchone():
            flash('Username already exists')
            return redirect(url_for('signup'))
            
        # Check if email exists
        cur.execute('SELECT * FROM users WHERE email = %s', (email,))
        if cur.fetchone():
            flash('Email already exists')
            return redirect(url_for('signup'))
        
        # Insert new user
        cur.execute('INSERT INTO users (username, email, password, phone) VALUES (%s, %s, %s, %s)',
                   (username, email, password, phone))
        mysql.connection.commit()
        cur.close()
        
        flash('Account created successfully! Please login.')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        cur = mysql.connection.cursor()
        cur.execute('SELECT * FROM users WHERE username = %s AND password = %s', (username, password))
        user = cur.fetchone()
        cur.close()
        
        if user:
            session['username'] = username
            return redirect(url_for('search'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/search', methods=['GET', 'POST'])
def search():
    if 'username' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        car_type = request.form.get('car_type', '').lower()
        distance = float(request.form.get('distance', 0))
        
        results = []
        
        # Use fallback data for EasyCar
        fallback = FALLBACK_DATA['easycar'][car_type]
        total_price = fallback['base_rate'] + (fallback['per_mile'] * distance)
        results.append({
            'company': 'EasyCar',
            'model': fallback['model'],
            'base_rate': fallback['base_rate'],
            'per_mile_rate': fallback['per_mile'],
            'distance': distance,
            'total_price': round(total_price, 2)
        })
        
        # Use fallback data for SpeedyRent
        fallback = FALLBACK_DATA['speedyrent'][car_type]
        total_price = fallback['base_rate'] + (fallback['per_mile'] * distance)
        results.append({
            'company': 'SpeedyRent',
            'model': fallback['model'],
            'base_rate': fallback['base_rate'],
            'per_mile_rate': fallback['per_mile'],
            'distance': distance,
            'total_price': round(total_price, 2)
        })
        
        # Sort results by price
        results.sort(key=lambda x: x['total_price'])
        
        return render_template('results_new.html', 
                             results=results, 
                             car_type=car_type,
                             distance=distance)
    
    return render_template('search.html')

@app.route('/chatbot', methods=['GET', 'POST'])
def chatbot():
    if request.method == 'POST':
        message = request.form.get('message', '').lower()
        
        # Simple chatbot logic
        if 'hello' in message or 'hi' in message:
            response = "Hello! How can I help you today?"
        elif 'price' in message or 'cost' in message:
            response = "Our prices vary based on car type and rental duration. Economy cars start from $45/day, Standard from $65/day, and Luxury from $110/day."
        elif 'car' in message or 'vehicle' in message:
            response = "We offer various types of cars: Economy, Standard, Luxury, and SUVs. What type are you interested in?"
        elif 'book' in message or 'reserve' in message:
            response = "To book a car, simply use our search feature to compare prices and select the best option for you."
        elif 'contact' in message:
            response = "You can reach our customer service at support@carcompare.com or call 1-800-CAR-RENT"
        else:
            response = "I'm not sure I understand. Can you please rephrase your question?"
            
        return jsonify({'response': response})
    
    return render_template('chatbot.html')

def init_db():
    with app.app_context():
        db.create_all()
        
        # Create tables for rental companies
        cur = mysql.connection.cursor()
        
        # Create users table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(80) UNIQUE NOT NULL,
                email VARCHAR(120) UNIQUE NOT NULL,
                password VARCHAR(120) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create search_history table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS search_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                car_type VARCHAR(50),
                distance FLOAT,
                search_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        # Create EasyCar inventory table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS easycar_inventory (
                id INT AUTO_INCREMENT PRIMARY KEY,
                car_type VARCHAR(50) NOT NULL,
                model VARCHAR(100) NOT NULL,
                base_rate DECIMAL(10,2) NOT NULL,
                per_mile_rate DECIMAL(10,2) NOT NULL,
                available BOOLEAN DEFAULT TRUE,
                features TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create SpeedyRent inventory table
        cur.execute('''
            CREATE TABLE IF NOT EXISTS speedyrent_inventory (
                id INT AUTO_INCREMENT PRIMARY KEY,
                car_type VARCHAR(50) NOT NULL,
                model VARCHAR(100) NOT NULL,
                base_rate DECIMAL(10,2) NOT NULL,
                per_mile_rate DECIMAL(10,2) NOT NULL,
                available BOOLEAN DEFAULT TRUE,
                features TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Insert sample data for EasyCar
        cur.execute('''
            INSERT IGNORE INTO easycar_inventory (car_type, model, base_rate, per_mile_rate, features) VALUES
            ('economy', 'Toyota Corolla', 45.00, 0.12, 'Bluetooth, Backup Camera, Cruise Control'),
            ('standard', 'Honda Civic', 65.00, 0.18, 'Apple CarPlay, Android Auto, Lane Departure Warning'),
            ('luxury', 'BMW 3 Series', 110.00, 0.28, 'Leather Seats, Navigation, Premium Audio'),
            ('suv', 'Toyota RAV4', 85.00, 0.22, 'All-Wheel Drive, Roof Rack, Spacious Interior')
        ''')
        
        # Insert sample data for SpeedyRent
        cur.execute('''
            INSERT IGNORE INTO speedyrent_inventory (car_type, model, base_rate, per_mile_rate, features) VALUES
            ('economy', 'Nissan Versa', 50.00, 0.15, 'USB Port, Air Conditioning, Keyless Entry'),
            ('standard', 'Hyundai Elantra', 70.00, 0.20, 'Blind Spot Monitor, Heated Seats, Sunroof'),
            ('luxury', 'Mercedes C-Class', 120.00, 0.30, 'Panoramic Sunroof, Premium Leather, Advanced Safety'),
            ('suv', 'Ford Explorer', 90.00, 0.25, 'Third Row Seating, Tow Package, Off-Road Mode')
        ''')
        
        mysql.connection.commit()
        cur.close()

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', debug=True, port=5000) 