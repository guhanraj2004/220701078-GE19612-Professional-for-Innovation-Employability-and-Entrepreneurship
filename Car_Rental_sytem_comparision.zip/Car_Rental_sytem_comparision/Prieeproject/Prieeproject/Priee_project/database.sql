-- Create the database
CREATE DATABASE IF NOT EXISTS car_rental_db;
USE car_rental_db;

-- Create users table
CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(120) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    otp_secret VARCHAR(32),
    is_verified BOOLEAN DEFAULT FALSE
);

-- Create car_rentals table
CREATE TABLE IF NOT EXISTS car_rentals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider VARCHAR(100) NOT NULL,
    car_type VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    distance DECIMAL(10,2) NOT NULL,
    pickup_date DATE NOT NULL,
    dropoff_date DATE NOT NULL,
    pickup_location VARCHAR(100) NOT NULL,
    dropoff_location VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    rental_id INT NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (rental_id) REFERENCES car_rentals(id)
);

-- Insert some sample car rental data
INSERT INTO car_rentals (provider, car_type, price, distance, pickup_date, dropoff_date, pickup_location, dropoff_location) VALUES
('Hertz', 'economy', 100.00, 100.00, '2024-03-20', '2024-03-25', 'New York', 'Boston'),
('Avis', 'compact', 150.00, 150.00, '2024-03-20', '2024-03-25', 'New York', 'Boston'),
('Enterprise', 'midsize', 200.00, 200.00, '2024-03-20', '2024-03-25', 'New York', 'Boston'),
('Budget', 'suv', 250.00, 250.00, '2024-03-20', '2024-03-25', 'New York', 'Boston'),
('National', 'luxury', 300.00, 300.00, '2024-03-20', '2024-03-25', 'New York', 'Boston');

-- Create indexes for better performance
CREATE INDEX idx_user_username ON user(username);
CREATE INDEX idx_user_email ON user(email);
CREATE INDEX idx_rentals_provider ON car_rentals(provider);
CREATE INDEX idx_rentals_car_type ON car_rentals(car_type);
CREATE INDEX idx_bookings_user_id ON bookings(user_id);
CREATE INDEX idx_bookings_rental_id ON bookings(rental_id); 