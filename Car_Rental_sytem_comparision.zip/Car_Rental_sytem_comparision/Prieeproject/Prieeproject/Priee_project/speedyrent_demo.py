from flask import Flask, jsonify, request
import random

app = Flask(__name__)

# Sample car inventory
CAR_INVENTORY = {
    'economy': {
        'models': ['Nissan Versa', 'Kia Rio', 'Mitsubishi Mirage'],
        'base_rate': 50.00,
        'per_mile': 0.15
    },
    'standard': {
        'models': ['Hyundai Elantra', 'Kia Forte', 'Mazda3'],
        'base_rate': 70.00,
        'per_mile': 0.20
    },
    'luxury': {
        'models': ['Mercedes C-Class', 'BMW 3 Series', 'Lexus IS'],
        'base_rate': 120.00,
        'per_mile': 0.30
    },
    'suv': {
        'models': ['Ford Explorer', 'Chevrolet Equinox', 'Jeep Grand Cherokee'],
        'base_rate': 90.00,
        'per_mile': 0.25
    }
}

@app.route('/')
def index():
    return "SpeedyRent Demo Website - Running on port 5002"

@app.route('/api/calculate_price')
def calculate_price():
    car_type = request.args.get('type', '').lower()
    distance = float(request.args.get('distance', 0))
    
    if car_type not in CAR_INVENTORY:
        return jsonify({'error': 'Invalid car type'}), 400
    
    car_data = CAR_INVENTORY[car_type]
    model = random.choice(car_data['models'])
    base_rate = car_data['base_rate']
    per_mile = car_data['per_mile']
    
    total_price = base_rate + (per_mile * distance)
    
    return jsonify({
        'model': model,
        'base_rate': base_rate,
        'per_mile_rate': per_mile,
        'distance': distance,
        'total_price': round(total_price, 2)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002) 