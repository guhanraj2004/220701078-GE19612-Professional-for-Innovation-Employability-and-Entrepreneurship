import subprocess
import sys
import time
import os

def run_command(command):
    if sys.platform == 'win32':
        return subprocess.Popen(command, shell=True, creationflags=subprocess.CREATE_NEW_CONSOLE)
    else:
        return subprocess.Popen(command, shell=True)

def main():
    # Get the directory of this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Start all applications
    print("Starting all applications...")
    
    # Start main application
    main_app = run_command(f'python "{os.path.join(script_dir, "app.py")}"')
    print("Main application started on port 5000")
    time.sleep(2)  # Wait for main app to initialize
    
    # Start EasyCar demo
    easycar = run_command(f'python "{os.path.join(script_dir, "easycar_demo.py")}"')
    print("EasyCar demo started on port 5001")
    time.sleep(2)  # Wait for EasyCar to initialize
    
    # Start SpeedyRent demo
    speedyrent = run_command(f'python "{os.path.join(script_dir, "speedyrent_demo.py")}"')
    print("SpeedyRent demo started on port 5002")
    
    print("\nAll applications are running!")
    print("Main application: http://localhost:5000")
    print("EasyCar demo: http://localhost:5001")
    print("SpeedyRent demo: http://localhost:5002")
    print("\nPress Ctrl+C to stop all applications")
    
    try:
        # Wait for all processes
        main_app.wait()
        easycar.wait()
        speedyrent.wait()
    except KeyboardInterrupt:
        print("\nStopping all applications...")
        main_app.terminate()
        easycar.terminate()
        speedyrent.terminate()
        print("All applications stopped")

if __name__ == '__main__':
    main() 