from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

# Demo inventory data
INVENTORY = {
    'economy': [
        {'model': 'Toyota Corolla', 'base_rate': 45.00, 'per_mile': 0.12, 'available': True},
        {'model': 'Honda Fit', 'base_rate': 42.00, 'per_mile': 0.11, 'available': True},
        {'model': 'Nissan Versa', 'base_rate': 40.00, 'per_mile': 0.10, 'available': True}
    ],
    'standard': [
        {'model': 'Honda Civic', 'base_rate': 65.00, 'per_mile': 0.18, 'available': True},
        {'model': 'Toyota Camry', 'base_rate': 70.00, 'per_mile': 0.20, 'available': True},
        {'model': 'Hyundai Elantra', 'base_rate': 60.00, 'per_mile': 0.16, 'available': True}
    ],
    'luxury': [
        {'model': 'BMW 3 Series', 'base_rate': 110.00, 'per_mile': 0.28, 'available': True},
        {'model': 'Mercedes C-Class', 'base_rate': 120.00, 'per_mile': 0.30, 'available': True},
        {'model': 'Audi A4', 'base_rate': 115.00, 'per_mile': 0.29, 'available': True}
    ],
    'suv': [
        {'model': 'Toyota RAV4', 'base_rate': 85.00, 'per_mile': 0.22, 'available': True},
        {'model': 'Honda CR-V', 'base_rate': 80.00, 'per_mile': 0.20, 'available': True},
        {'model': 'Ford Escape', 'base_rate': 75.00, 'per_mile': 0.18, 'available': True}
    ]
}

@app.route('/')
def index():
    return render_template('easycar_index.html')

@app.route('/api/search')
def search():
    car_type = request.args.get('type', 'economy')
    if car_type not in INVENTORY:
        return jsonify({'error': 'Invalid car type'}), 400
    
    # Simulate real-time availability
    available_cars = []
    for car in INVENTORY[car_type]:
        if random.random() > 0.3:  # 70% chance of being available
            car['available'] = True
            available_cars.append(car)
        else:
            car['available'] = False
    
    return jsonify({
        'cars': available_cars,
        'provider': 'EasyCar',
        'website': 'https://www.easycar.com'
    })

@app.route('/api/calculate_price')
def calculate_price():
    car_type = request.args.get('type')
    distance = float(request.args.get('distance', 0))
    
    if car_type not in INVENTORY:
        return jsonify({'error': 'Invalid car type'}), 400
    
    available_cars = [car for car in INVENTORY[car_type] if car['available']]
    if not available_cars:
        return jsonify({'error': 'No cars available'}), 404
    
    # Get the cheapest available car
    car = min(available_cars, key=lambda x: x['base_rate'])
    total_price = car['base_rate'] + (car['per_mile'] * distance)
    
    return jsonify({
        'model': car['model'],
        'base_rate': car['base_rate'],
        'per_mile': car['per_mile'],
        'total_price': total_price
    })

if __name__ == '__main__':
    app.run(port=5001) 