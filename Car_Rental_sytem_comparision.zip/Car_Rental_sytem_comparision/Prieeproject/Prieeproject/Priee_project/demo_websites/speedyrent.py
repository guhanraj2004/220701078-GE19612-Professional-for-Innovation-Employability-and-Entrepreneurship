from flask import Flask, render_template, jsonify, request
import random

app = Flask(__name__)

# Demo inventory data
INVENTORY = {
    'economy': [
        {'model': 'Nissan Versa', 'base_rate': 50.00, 'per_mile': 0.15, 'available': True},
        {'model': 'Kia Rio', 'base_rate': 48.00, 'per_mile': 0.14, 'available': True},
        {'model': 'Mitsubishi Mirage', 'base_rate': 45.00, 'per_mile': 0.13, 'available': True}
    ],
    'standard': [
        {'model': 'Hyundai Elantra', 'base_rate': 70.00, 'per_mile': 0.20, 'available': True},
        {'model': 'Kia Forte', 'base_rate': 65.00, 'per_mile': 0.18, 'available': True},
        {'model': 'Mazda3', 'base_rate': 75.00, 'per_mile': 0.22, 'available': True}
    ],
    'luxury': [
        {'model': 'Mercedes C-Class', 'base_rate': 120.00, 'per_mile': 0.30, 'available': True},
        {'model': 'BMW 5 Series', 'base_rate': 130.00, 'per_mile': 0.32, 'available': True},
        {'model': 'Lexus ES', 'base_rate': 125.00, 'per_mile': 0.31, 'available': True}
    ],
    'suv': [
        {'model': 'Ford Explorer', 'base_rate': 90.00, 'per_mile': 0.25, 'available': True},
        {'model': 'Chevrolet Equinox', 'base_rate': 85.00, 'per_mile': 0.23, 'available': True},
        {'model': 'Jeep Grand Cherokee', 'base_rate': 95.00, 'per_mile': 0.27, 'available': True}
    ]
}

@app.route('/')
def index():
    return render_template('speedyrent_index.html')

@app.route('/api/search')
def search():
    car_type = request.args.get('type', 'economy')
    if car_type not in INVENTORY:
        return jsonify({'error': 'Invalid car type'}), 400
    
    # Simulate real-time availability
    available_cars = []
    for car in INVENTORY[car_type]:
        if random.random() > 0.3:  # 70% chance of being available
            car['available'] = True
            available_cars.append(car)
        else:
            car['available'] = False
    
    return jsonify({
        'cars': available_cars,
        'provider': 'SpeedyRent',
        'website': 'https://www.speedyrent.com'
    })

@app.route('/api/calculate_price')
def calculate_price():
    car_type = request.args.get('type')
    distance = float(request.args.get('distance', 0))
    
    if car_type not in INVENTORY:
        return jsonify({'error': 'Invalid car type'}), 400
    
    available_cars = [car for car in INVENTORY[car_type] if car['available']]
    if not available_cars:
        return jsonify({'error': 'No cars available'}), 404
    
    # Get the cheapest available car
    car = min(available_cars, key=lambda x: x['base_rate'])
    total_price = car['base_rate'] + (car['per_mile'] * distance)
    
    return jsonify({
        'model': car['model'],
        'base_rate': car['base_rate'],
        'per_mile': car['per_mile'],
        'total_price': total_price
    })

if __name__ == '__main__':
    app.run(port=5002) 