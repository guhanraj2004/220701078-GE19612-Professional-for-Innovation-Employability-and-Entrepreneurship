// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;

    const inputs = form.querySelectorAll('input[required], select[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.classList.add('is-invalid');
        } else {
            input.classList.remove('is-invalid');
        }
    });

    return isValid;
}

// Date validation
function validateDates() {
    const pickupDate = document.getElementById('pickup_date');
    const dropoffDate = document.getElementById('dropoff_date');

    if (pickupDate && dropoffDate) {
        const pickup = new Date(pickupDate.value);
        const dropoff = new Date(dropoffDate.value);

        if (dropoff < pickup) {
            dropoffDate.setCustomValidity('Drop-off date must be after pickup date');
            return false;
        } else {
            dropoffDate.setCustomValidity('');
            return true;
        }
    }
}

// Phone number validation
function validatePhone(input) {
    const phoneRegex = /^\+?[\d\s-]{10,}$/;
    if (!phoneRegex.test(input.value)) {
        input.setCustomValidity('Please enter a valid phone number');
        return false;
    } else {
        input.setCustomValidity('');
        return true;
    }
}

// Password strength validation
function validatePassword(input) {
    const password = input.value;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < 8) {
        input.setCustomValidity('Password must be at least 8 characters long');
        return false;
    }

    if (!hasUpperCase || !hasLowerCase || !hasNumbers || !hasSpecialChar) {
        input.setCustomValidity('Password must contain uppercase, lowercase, numbers, and special characters');
        return false;
    }

    input.setCustomValidity('');
    return true;
}

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Add form validation listeners
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(form.id)) {
                e.preventDefault();
                alert('Please fill in all required fields');
            }
        });
    });

    // Add phone validation listener
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            validatePhone(this);
        });
    });

    // Add password validation listener
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        input.addEventListener('input', function() {
            validatePassword(this);
        });
    });

    // Add date validation listeners
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.addEventListener('change', validateDates);
    });
}); 