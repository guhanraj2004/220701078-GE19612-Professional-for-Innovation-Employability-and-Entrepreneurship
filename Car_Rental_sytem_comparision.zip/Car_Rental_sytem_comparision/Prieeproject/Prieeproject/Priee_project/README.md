# Car Rental Price Comparison Website

A web application that allows users to compare car rental prices across multiple providers. Built with Flask, MySQL, and modern web technologies.

## Features

- User authentication (signup/login)
- Real-time price comparison across multiple rental providers
- Interactive chatbot for customer support
- Responsive design for all devices
- Price filtering and sorting
- Detailed car information and features
- User-friendly interface

## Prerequisites

- Python 3.8 or higher
- MySQL Server
- pip (Python package manager)

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd car-rental-comparison
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install the required packages:
```bash
pip install -r requirements.txt
```

4. Set up the MySQL database:
```bash
mysql -u root -p
```
```sql
CREATE DATABASE car_rental_db;
```

5. Create a `.env` file in the project root with the following variables:
```
SECRET_KEY=your-secret-key-here
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=mysql123
MYSQL_DB=car_rental_db
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-email-password
```

## Running the Application

1. Initialize the database:
```bash
python app.py
```

2. Access the application:
- Open your web browser and navigate to `http://localhost:5000`
- The application will automatically create necessary database tables on first run

## Project Structure

```
car-rental-comparison/
├── app.py                 # Main application file
├── requirements.txt       # Project dependencies
├── .env                  # Environment variables (create this)
├── static/
│   ├── css/
│   │   └── style.css    # Custom styles
│   ├── js/
│   │   └── main.js      # Custom JavaScript
│   └── images/          # Image assets
└── templates/
    ├── base.html        # Base template
    ├── index.html       # Home page
    ├── login.html       # Login page
    ├── signup.html      # Signup page
    ├── search.html      # Search form
    ├── results.html     # Search results
    └── chatbot.html     # Chatbot interface
```

## Development

- The application uses Flask for the backend
- Bootstrap 5 for responsive design
- MySQL for data storage
- Flask-Login for user authentication
- Flask-Mail for email functionality

## API Documentation

### Authentication Endpoints

- `POST /signup` - Create a new user account
- `POST /login` - Authenticate user and create session
- `GET /logout` - End user session

### Car Rental Endpoints

- `GET /search` - Display search form
- `POST /search` - Process search and return results
- `GET /chatbot` - Display chatbot interface
- `POST /chatbot` - Process chatbot messages

## Contributing

1. Fork the repository
2. Create a new branch for your feature
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@carcompare.com or create an issue in the repository. 