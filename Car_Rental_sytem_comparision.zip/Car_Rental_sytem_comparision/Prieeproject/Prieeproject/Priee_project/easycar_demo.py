from flask import Flask, jsonify, request
import random

app = Flask(__name__)

# Sample car inventory
CAR_INVENTORY = {
    'economy': {
        'models': ['Toyota Corolla', 'Honda Civic', 'Nissan Versa'],
        'base_rate': 45.00,
        'per_mile': 0.12
    },
    'standard': {
        'models': ['Honda Accord', 'Toyota Camry', 'Hyundai Elantra'],
        'base_rate': 65.00,
        'per_mile': 0.18
    },
    'luxury': {
        'models': ['BMW 3 Series', 'Mercedes C-Class', 'Audi A4'],
        'base_rate': 110.00,
        'per_mile': 0.28
    },
    'suv': {
        'models': ['Toyota RAV4', 'Honda CR-V', 'Ford Explorer'],
        'base_rate': 85.00,
        'per_mile': 0.22
    }
}

@app.route('/')
def index():
    return "EasyCar Demo Website - Running on port 5001"

@app.route('/api/calculate_price')
def calculate_price():
    car_type = request.args.get('type', '').lower()
    distance = float(request.args.get('distance', 0))
    
    if car_type not in CAR_INVENTORY:
        return jsonify({'error': 'Invalid car type'}), 400
    
    car_data = CAR_INVENTORY[car_type]
    model = random.choice(car_data['models'])
    base_rate = car_data['base_rate']
    per_mile = car_data['per_mile']
    
    total_price = base_rate + (per_mile * distance)
    
    return jsonify({
        'model': model,
        'base_rate': base_rate,
        'per_mile_rate': per_mile,
        'distance': distance,
        'total_price': round(total_price, 2)
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001) 